
Orchestration Analyzer - An orchestration analysis tool for composers, conductors, musicians and music therists
Copyright (c) 2020 Uljas Pulkkis

This is an app for my doctoral project. You can use it online: orchestrationanalyer.herokuapp.com or install with pip and launch from your own machine.